mod common;

#[path = "codecs/mp3_decoder_test.rs"]
mod mp3_decoder_test;

#[path = "codecs/aac_decoder_test.rs"]
mod aac_decoder_test;

#[path = "codecs/h264_decoder_test.rs"]
mod h264_decoder_test;

#[path = "codecs/pcm_codec_test.rs"]
mod pcm_codec_test;

#[path = "codecs/adpcm_decoder_test.rs"]
mod adpcm_decoder_test;

#[path = "codecs/flac_codec_test.rs"]
mod flac_codec_test;

#[path = "codecs/opus_decoder_test.rs"]
mod opus_decoder_test;
#[path = "codecs/opus_plc_test.rs"]
mod opus_plc_test;

#[path = "codecs/encoder_test.rs"]
mod encoder_test;

#[path = "codecs/vorbis_decoder_test.rs"]
mod vorbis_decoder_test;

#[path = "codecs/vp9_decoder_test.rs"]
mod vp9_decoder_test;

#[path = "codecs/ac3_decoder_test.rs"]
mod ac3_decoder_test;

#[cfg(feature = "av1")]
#[path = "codecs/av1_decoder_test.rs"]
mod av1_decoder_test;

#[path = "codecs/hevc_decoder_test.rs"]
mod hevc_decoder_test;

#[path = "codecs/subtitle_decoder_test.rs"]
mod subtitle_decoder_test;

#[path = "codecs/alac_decoder_test.rs"]
mod alac_decoder_test;

#[path = "codecs/vp8_decoder_test.rs"]
mod vp8_decoder_test;
