//! Decode → convert → encode → mux, like `ffmpeg -i in [options] out`.
//!
//! This is the pipeline behind the `rmp` command-line tool and the
//! `transcode` example. Each input stream is either copied (packets go
//! straight to the muxer) or decoded, converted with
//! [`AudioConverter`]/[`VideoConverter`] and re-encoded.
//!
//! The output container comes from the output extension (or
//! [`Options::format`]). When no codec is given, each container gets a
//! sensible default:
//!
//! | Output | Audio | Video | Subtitles |
//! | --- | --- | --- | --- |
//! | `.wav` | `pcm_s16le` | dropped | dropped |
//! | `.flac` | `flac` | dropped | dropped |
//! | `.mp3` | copy | dropped | dropped |
//! | `.y4m` | dropped | `rawvideo` | dropped |
//! | `.mp4`, `.mov` | copy when MP4 holds the codec, else `aac` | copy when MP4 holds the codec (`h264` when converting or when it doesn't, e.g. VP9) | dropped |
//! | `.m4a` | as `.mp4` | dropped | dropped |
//! | `.mkv` | copy when Matroska holds the codec, else `flac` | copy (`h264` when converting) | copy |
//! | `.mka` | as `.mkv` | dropped | copy |
//! | `.webm` | copy (Opus/Vorbis only) | copy (VP8/VP9/AV1 only) | copy (WebVTT only) |
//! | `.ogg`, `.oga` | copy for Opus/FLAC/Vorbis, else `flac` | dropped | dropped |
//! | `.opus` | copy (Opus only) | dropped | dropped |
//! | `.ts`, `.m2ts` | copy when MPEG-TS holds the codec (AAC, MP2/MP3, AC-3, E-AC-3, Opus), else `aac` | copy when it holds it (H.264, HEVC, MPEG-2, MPEG-4), else `h264` | dropped |
//! | `.m3u8` (HLS) | as `.ts` (as `.mp4` with `-hls_segment_type fmp4`) | as `.ts` | WebVTT / SubRip as WebVTT renditions |
//! | `.vtt` | dropped | dropped | WebVTT / SubRip |
//!
//! RMP's encoders are AAC-LC, FLAC, PCM, H.264 (Constrained Baseline) and
//! raw video, so a transcode can produce those codecs; anything else is a
//! stream copy. Video is "converted" by `-s`, `-pix_fmt`, `-b:v` or `-qp`,
//! or by naming a codec with `-c:v`.

use std::collections::HashMap;

use crate::Message;
use crate::codecs::aac::{self, AacEncoder};
use crate::codecs::flac::FlacEncoder;
use crate::codecs::h264::H264Encoder;
use crate::codecs::pcm::PcmCodec;
use crate::codecs::threading;
use crate::container::mkv::tracks::mux_codec;
use crate::container::mp4::codec::muxer_supports;
use crate::core::traits::*;
use crate::core::{
	CodecId, Frame, Metadata, Packet, Pixel, RawValue, Resolver, SampleFormat, SampleLayout, State,
	Stream, StreamId, StreamKind, TimeBase,
};
use crate::io::{Input, Output};
use crate::message::Result;
use crate::process::{
	AudioConverter, AudioSpec, Dither, DitherMethod, ScaleFilter, VideoConverter, VideoOptions,
	VideoSpec, audio::Gapless, dither::DITHER_METHODS,
};

/// What to do with the input, in FFmpeg's option vocabulary.
#[derive(Debug, Clone, Default)]
pub struct Options {
	/// `-an`, `-vn`, `-sn`: drop audio, video or subtitle streams.
	pub no_audio: bool,
	pub no_video: bool,
	pub no_subtitles: bool,
	/// `-c:a`, `-c:v`, `-c:s`: codec name or `copy`.
	pub audio_codec: Option<String>,
	pub video_codec: Option<String>,
	pub subtitle_codec: Option<String>,
	/// `-ar`, `-ac`, `-sample_fmt`.
	pub sample_rate: Option<u32>,
	pub channels: Option<u8>,
	pub sample_format: Option<(SampleFormat, SampleLayout)>,
	/// `-compression_level` (FLAC 0-12, default 5).
	pub level: Option<u8>,
	/// `-b:a`, `-b:v`: target bit rates in bits per second (`128k`, `2M`).
	pub audio_bitrate: Option<u32>,
	pub video_bitrate: Option<u32>,
	/// `-qp`: constant H.264 quantiser (0-51).
	pub qp: Option<u8>,
	/// `-g`: H.264 keyframe interval in frames.
	pub gop: Option<u32>,
	/// `-s WxH`, `-pix_fmt`, `-sws_flags`.
	pub size: Option<(u32, u32)>,
	pub pixel: Option<Pixel>,
	pub filter: ScaleFilter,
	/// `-f`: output container by name instead of by extension.
	pub format: Option<String>,
	/// `-metadata key=value`, applied over the input's tags.
	pub metadata: Vec<(String, String)>,
	/// `-map_metadata -1`: don't copy the input's tags.
	pub drop_metadata: bool,
	/// `-dither_method`, `-dither_scale`: how audio is rounded to integer
	/// samples. `None` means RMP's default, triangular (TPDF) dither
	/// whenever precision is lost; `-dither_method none` gives FFmpeg's
	/// default (plain rounding), bit for bit.
	pub dither: Option<Dither>,
	/// `-movflags`, `-frag_duration`, `-min_frag_duration`: MP4 layout
	/// (`+faststart`, fragmented MP4), as `(name, value)` without the dash.
	pub container_options: Vec<(String, String)>,
	/// `-threads`: threads per codec, and whether demux, decode and encode
	/// run on threads of their own (any value above 1). `None` or `0`:
	/// automatic ([`threading::default_threads`]); `1`: everything on the
	/// calling thread.
	pub threads: Option<usize>,
}

/// What a finished transcode did.
#[derive(Debug, Clone, Default)]
pub struct Summary {
	/// One line per output stream, e.g. `stream 1: audio aac -> flac (48000 Hz, 2 ch)`.
	pub streams: Vec<String>,
	/// Frames decoded and re-encoded.
	pub frames: u64,
	/// Packets written to the output.
	pub packets: u64,
}

/// Parses `-sample_fmt` names: `u8`, `s16`, `s32`, `s64`, `flt`, `dbl`,
/// with a `p` suffix for planar.
pub fn parse_sample_format(name: &str) -> Option<(SampleFormat, SampleLayout)> {
	let (base, layout) = match name.strip_suffix('p') {
		Some(b) if b != "s" => (b, SampleLayout::Planar),
		_ => (name, SampleLayout::Interleaved),
	};
	let format = match base {
		"u8" => SampleFormat::U8,
		"s16" => SampleFormat::S16,
		"s32" => SampleFormat::S32,
		"s64" => SampleFormat::S64,
		"flt" => SampleFormat::F32,
		"dbl" => SampleFormat::F64,
		_ => return None,
	};
	Some((format, layout))
}

impl Options {
	/// Options that take no value.
	pub fn is_flag(option: &str) -> bool {
		matches!(option, "-an" | "-vn" | "-sn")
	}

	/// `true` for every option [`Options::apply`] understands.
	pub fn is_option(option: &str) -> bool {
		Self::is_flag(option)
			|| matches!(
				option,
				"-c:a"
					| "-acodec"
					| "-c:v"
					| "-vcodec"
					| "-c:s"
					| "-scodec"
					| "-codec"
					| "-c"
					| "-ar"
					| "-ac"
					| "-sample_fmt"
					| "-compression_level"
					| "-b:a"
					| "-ab"
					| "-b:v"
					| "-vb"
					| "-qp"
					| "-g"
					| "-s"
					| "-pix_fmt"
					| "-sws_flags"
					| "-f"
					| "-metadata"
					| "-map_metadata"
					| "-dither_method"
					| "-dither_scale"
					| "-movflags"
					| "-frag_duration"
					| "-min_frag_duration"
					| "-threads"
			) || Self::is_container_option(option)
	}

	/// HLS and MPEG-TS muxer options (`-hls_time`, `-mpegts_service_id`, ...).
	pub fn is_container_option(option: &str) -> bool {
		let Some(name) = option.strip_prefix('-') else { return false };
		crate::container::hls::muxer::HLS_OPTIONS.contains(&name)
			|| crate::container::mpegts::muxer::TS_OPTIONS.contains(&name)
	}

	/// Applies one option (`value` is `None` for flags).
	pub fn apply(&mut self, option: &str, value: Option<&str>) -> std::result::Result<(), String> {
		let need = || value.ok_or_else(|| format!("option {option} needs a value"));
		let number = |v: &str| v.parse::<u32>().map_err(|_| format!("invalid value for {option}: {v}"));
		match option {
			"-an" => self.no_audio = true,
			"-vn" => self.no_video = true,
			"-sn" => self.no_subtitles = true,
			"-c:a" | "-acodec" => self.audio_codec = Some(need()?.to_string()),
			"-c:v" | "-vcodec" => self.video_codec = Some(need()?.to_string()),
			"-c:s" | "-scodec" => self.subtitle_codec = Some(need()?.to_string()),
			"-c" | "-codec" => {
				let v = need()?;
				if v != "copy" {
					return Err(format!("{option} only accepts copy; use -c:a / -c:v for codecs"));
				}
				self.audio_codec = Some(v.into());
				self.video_codec = Some(v.into());
				self.subtitle_codec = Some(v.into());
			}
			"-threads" => {
				let v = need()?;
				// FFmpeg's `auto` is the default.
				self.threads = if v == "auto" { None } else { Some(number(v)? as usize) };
			}
			"-ar" => self.sample_rate = Some(number(need()?)?),
			"-ac" => {
				let v = need()?;
				let n = number(v)?;
				self.channels = Some(
					u8::try_from(n)
						.ok()
						.filter(|&c| (1..=8).contains(&c))
						.ok_or_else(|| format!("invalid channel count: {v}"))?,
				);
			}
			"-sample_fmt" => {
				let v = need()?;
				self.sample_format =
					Some(parse_sample_format(v).ok_or_else(|| format!("unknown sample format: {v}"))?);
			}
			"-compression_level" => {
				let v = need()?;
				let n = number(v)?;
				self.level = Some(
					u8::try_from(n)
						.ok()
						.filter(|&l| l <= 12)
						.ok_or_else(|| format!("compression level must be 0-12: {v}"))?,
				);
			}
			"-b:a" | "-ab" => self.audio_bitrate = Some(parse_bitrate(need()?)?),
			"-b:v" | "-vb" => self.video_bitrate = Some(parse_bitrate(need()?)?),
			"-qp" => {
				let v = need()?;
				let n = number(v)?;
				self.qp = Some(
					u8::try_from(n)
						.ok()
						.filter(|&q| q <= 51)
						.ok_or_else(|| format!("-qp must be 0-51: {v}"))?,
				);
			}
			"-g" => {
				let v = need()?;
				let n = number(v)?;
				if n == 0 {
					return Err(format!("-g must be at least 1: {v}"));
				}
				self.gop = Some(n);
			}
			"-s" => {
				let v = need()?;
				let (w, h) = v.split_once('x').ok_or_else(|| format!("invalid size {v}, expected WxH"))?;
				let (w, h) = (number(w)?, number(h)?);
				if w == 0 || h == 0 {
					return Err(format!("invalid size {v}"));
				}
				self.size = Some((w, h));
			}
			"-pix_fmt" => {
				let v = need()?;
				self.pixel =
					Some(Pixel::from_name(v).ok_or_else(|| format!("unsupported pixel format: {v}"))?);
			}
			"-sws_flags" => {
				let v = need()?;
				self.filter = ScaleFilter::from_name(v).ok_or_else(|| format!("unknown scaler: {v}"))?;
			}
			"-f" => self.format = Some(need()?.to_ascii_lowercase()),
			"-metadata" => {
				let v = need()?;
				let (key, value) =
					v.split_once('=').ok_or_else(|| format!("-metadata expects key=value: {v}"))?;
				self.metadata.push((key.to_string(), value.to_string()));
			}
			"-map_metadata" => {
				if need()? != "-1" {
					return Err("-map_metadata only supports -1 (drop the input's tags)".into());
				}
				self.drop_metadata = true;
			}
			"-dither_method" => {
				let v = need()?;
				let method = DitherMethod::from_name(v)
					.ok_or_else(|| format!("unknown dither method {v} (one of: {DITHER_METHODS})"))?;
				self.dither = Some(Dither { method, ..self.dither.unwrap_or(Dither::TRIANGULAR) });
			}
			"-dither_scale" => {
				let v = need()?;
				let scale = v
					.parse::<f64>()
					.ok()
					.filter(|s| s.is_finite() && (0.0..=8.0).contains(s))
					.ok_or_else(|| format!("-dither_scale must be 0 to 8: {v}"))?;
				self.dither = Some(Dither { scale, ..self.dither.unwrap_or(Dither::TRIANGULAR) });
			}
			"-movflags" | "-frag_duration" | "-min_frag_duration" => {
				let v = need()?;
				let key = &option[1..];
				// Check the value now, so a typo fails before any work.
				let mut check = crate::container::mp4::options::Mp4Options::default();
				for (k, v) in &self.container_options {
					let _ = check.set(k, v);
				}
				check.set(key, v).map_err(|e| {
					let reason = match e {
						Message::Container(s) | Message::Other(s) | Message::Codec(s) => s.to_string(),
						Message::Io(e) => e.to_string(),
					};
					format!("{reason}: {v} (-movflags: {})", crate::container::mp4::options::MOVFLAGS)
				})?;
				self.container_options.push((key.to_string(), v.to_string()));
			}
			other if Self::is_container_option(other) => {
				let v = need()?;
				let key = &other[1..];
				// Check the value now, so a typo fails before any work.
				let mut check = crate::container::hls::muxer::HlsOptions::default();
				check.set(key, v).map_err(|e| match e {
					Message::Container(s) | Message::Other(s) | Message::Codec(s) => format!("{s}: {v}"),
					Message::Io(e) => e.to_string(),
				})?;
				self.container_options.push((key.to_string(), v.to_string()));
			}
			other => return Err(format!("unknown option {other}")),
		}
		Ok(())
	}

	/// `-ar`, `-ac` or `-sample_fmt` was given.
	pub fn converts_audio(&self) -> bool {
		self.sample_rate.is_some() || self.channels.is_some() || self.sample_format.is_some()
	}

	/// `-s` or `-pix_fmt` was given.
	pub fn converts_video(&self) -> bool {
		self.size.is_some() || self.pixel.is_some()
	}

	/// Parses a list of options such as `["-c:a", "flac", "-ar", "48000"]`.
	pub fn parse(args: &[String]) -> std::result::Result<Self, String> {
		let mut options = Self::default();
		let mut i = 0;
		while i < args.len() {
			let option = args[i].as_str();
			if Self::is_flag(option) {
				options.apply(option, None)?;
				i += 1;
			} else {
				options.apply(option, args.get(i + 1).map(String::as_str))?;
				i += 2;
			}
		}
		Ok(options)
	}
}

/// Parses a bit rate such as `128000`, `128k` or `2.5M` (FFmpeg's SI
/// suffixes).
pub fn parse_bitrate(value: &str) -> std::result::Result<u32, String> {
	let bad = || format!("invalid bit rate: {value}");
	let (number, scale) = match value.chars().last() {
		Some('k' | 'K') => (&value[..value.len() - 1], 1e3),
		Some('M' | 'm') => (&value[..value.len() - 1], 1e6),
		_ => (value, 1.0),
	};
	let v = number.parse::<f64>().map_err(|_| bad())? * scale;
	if !(1000.0..=4.0e9).contains(&v) {
		return Err(bad());
	}
	Ok(v.round() as u32)
}

/// Applies `-metadata` pairs, using the field names FFmpeg uses.
pub fn apply_metadata(metadata: &mut Metadata, pairs: &[(String, String)]) {
	for (key, value) in pairs {
		let text = (!value.is_empty()).then(|| value.clone());
		let number = |v: &str| v.split('/').next().and_then(|n| n.trim().parse::<u32>().ok());
		match key.to_ascii_lowercase().as_str() {
			"title" => metadata.title = text,
			"artist" => metadata.artist = text,
			"album" => metadata.album = text,
			"album_artist" => metadata.album_artist = text,
			"genre" => metadata.genre = text,
			"date" | "year" => metadata.date = text,
			"comment" => metadata.comment = text,
			"description" => metadata.description = text,
			"lyrics" => metadata.lyrics = text,
			"track" => {
				metadata.track_number = number(value);
				metadata.tracks_total = value.split('/').nth(1).and_then(|t| t.trim().parse().ok());
			}
			"disc" => {
				metadata.disc_number = number(value);
				metadata.discs_total = value.split('/').nth(1).and_then(|t| t.trim().parse().ok());
			}
			other => {
				if value.is_empty() {
					metadata.raw.remove(other);
				} else {
					metadata.raw.insert(other.to_string(), RawValue::String(value.clone()));
				}
			}
		}
	}
}

/// What happens to one input stream.
enum Route {
	Copy { out: StreamId },
	Audio(Box<AudioRoute>),
	Video(Box<VideoRoute>),
}

struct AudioRoute {
	out: StreamId,
	encoder: Box<dyn Encoder>,
	enc_state: State,
	target: AudioSpec,
	/// Significant bits of an integer target (24 for `pcm_s24le` or 24-bit
	/// FLAC held in `S32`), and how to round to them.
	precision: u32,
	dither: Dither,
	converter: Option<AudioConverter>,
	/// Source priming / padding to drop from the decoded audio.
	gapless: Gapless,
}

struct VideoRoute {
	out: StreamId,
	encoder: Box<dyn Encoder>,
	enc_state: State,
	target: (Option<(u32, u32)>, Option<Pixel>),
	filter: ScaleFilter,
	converter: Option<VideoConverter>,
}

/// Output container name: `-f`, else the output extension.
pub fn container_of(output: &str, options: &Options) -> String {
	options
		.format
		.clone()
		.unwrap_or_else(|| output.rsplit('.').next().unwrap_or("").to_ascii_lowercase())
}

/// Bit depth a decoded stream will most likely have.
fn source_bits(stream: &Stream) -> u8 {
	let id = stream.parameters.codec.id.as_str();
	if let Some(bits) = stream.parameters.bits_per_sample {
		return bits;
	}
	match PcmCodec::from_id(id) {
		Some(codec) => match codec.sample_format() {
			SampleFormat::U8 | SampleFormat::S16 => 16,
			_ => 24,
		},
		None => 16,
	}
}

/// Significant bits the encoder keeps from its integer input.
fn target_precision(codec: &str, out: &Stream, format: SampleFormat) -> u32 {
	let container = (format.bytes() * 8) as u32;
	let coded = match codec {
		"flac" => out.parameters.bits_per_sample.map_or(container, u32::from),
		"pcm_s24le" | "pcm_s24be" => 24,
		_ => container,
	};
	coded.min(container)
}

fn audio_target(stream: &Stream, codec: &str, o: &Options) -> Result<(Stream, AudioSpec)> {
	let p = &stream.parameters;
	let rate = o.sample_rate.or(p.sample_rate).ok_or("input audio has no sample rate")?;
	let channels = o.channels.or(p.channels).ok_or("input audio has no channel count")?;
	let mut out = Stream::audio(StreamId(0), rate, channels, CodecId::new(codec));
	out.metadata = stream.metadata.clone();
	let (format, layout) = if codec == "flac" {
		let bits = match o.sample_format {
			Some((SampleFormat::U8 | SampleFormat::S16, _)) => 16,
			Some(_) => 24,
			None => source_bits(stream).clamp(16, 24),
		};
		out.parameters.bits_per_sample = Some(if bits > 16 { 24 } else { 16 });
		let encoder = FlacEncoder::new(StreamId(0)).with_level(o.level.unwrap_or(5));
		out.parameters.extradata = encoder.extradata(&out.parameters)?;
		(if bits > 16 { SampleFormat::S32 } else { SampleFormat::S16 }, SampleLayout::Interleaved)
	} else if codec == "aac" {
		let encoder = AacEncoder::new(StreamId(0)).with_bitrate(o.audio_bitrate);
		out.parameters.extradata = encoder.extradata(&out.parameters)?;
		out.parameters.bitrate = Some(encoder.bitrate_for(&out.parameters));
		(SampleFormat::F32, SampleLayout::Planar)
	} else {
		let pcm = PcmCodec::from_id(codec).ok_or(Message::Codec(
			"unsupported audio codec: RMP encodes aac, flac and pcm_* (or use -c:a copy)",
		))?;
		(pcm.sample_format(), SampleLayout::Interleaved)
	};
	// Gapless metadata describes the source's timing: the transcode drops
	// those samples (see `gapless_of`), and the encoder states its own.
	out.metadata.raw.remove("encoder_delay");
	out.metadata.raw.remove("encoder_padding");
	if codec == "aac" {
		// The encoder's priming; the MP4 muxer turns it into an edit list.
		out
			.metadata
			.raw
			.insert("encoder_delay".into(), RawValue::String(aac::encoder::ENCODER_DELAY.to_string()));
	}
	let format = o.sample_format.map_or((format, layout), |f| f);
	Ok((out, AudioSpec::new(rate, channels, format.0, format.1)))
}

/// Priming and padding samples to drop from a decoded stream, from the
/// demuxer's gapless metadata.
fn gapless_of(stream: &Stream) -> Gapless {
	let samples = |key: &str| match stream.metadata.raw.get(key) {
		Some(RawValue::String(v)) => v.parse::<u64>().unwrap_or(0),
		_ => 0,
	};
	Gapless::new(samples("encoder_delay"), samples("encoder_padding"))
}

/// Frame rate of a video stream from its first packet duration.
fn frame_time_base(stream: &Stream, first_duration: Option<u64>) -> TimeBase {
	let tb = stream.time_base;
	match first_duration.filter(|&d| d > 0 && d < u64::from(u32::MAX)) {
		Some(d) => TimeBase::new(tb.num.saturating_mul(d as u32), tb.den),
		None => TimeBase::new(1, 25),
	}
}

fn is_ts(ext: &str) -> bool {
	matches!(ext, "ts" | "m2t" | "mts" | "m2ts" | "mpegts" | "trp")
}

fn is_hls(ext: &str) -> bool {
	matches!(ext, "m3u8" | "hls")
}

/// The container an HLS output's segments use.
fn hls_segments_are_mp4(options: &Options) -> bool {
	options.container_options.iter().any(|(k, v)| k == "hls_segment_type" && v == "fmp4")
}

/// Whether the output's media container holds a codec as it is.
fn output_holds(ext: &str, options: &Options, codec: &str) -> bool {
	if is_hls(ext) && hls_segments_are_mp4(options) {
		return muxer_supports(codec);
	}
	crate::container::mpegts::muxer::supports(codec)
}

fn matroska_holds(stream: &Stream, webm: bool) -> bool {
	mux_codec(&stream.parameters, webm).is_ok()
}

/// Default audio codec for a container (`None`: drop audio).
fn default_audio(ext: &str, stream: &Stream, options: &Options) -> Option<&'static str> {
	let codec = stream.parameters.codec.id.as_str();
	Some(match ext {
		"y4m" | "vtt" | "webvtt" => return None,
		_ if (is_ts(ext) || is_hls(ext)) && output_holds(ext, options, codec) => "copy",
		_ if is_ts(ext) || is_hls(ext) => "aac",
		"wav" => "pcm_s16le",
		"flac" => "flac",
		"mp3" => "copy",
		"mp4" | "m4a" | "mov" if muxer_supports(codec) => "copy",
		"mp4" | "m4a" | "mov" => "aac",
		"mkv" | "mka" | "mks" if matroska_holds(stream, false) => "copy",
		// WebM and .opus only hold codecs RMP can't encode: copy, and let
		// the muxer explain when the codec doesn't fit.
		"webm" | "opus" => "copy",
		"ogg" | "oga" if matches!(codec, "opus" | "flac" | "vorbis") => "copy",
		_ => "flac",
	})
}

/// Whether a container takes video / subtitle streams by default.
fn keeps_video(ext: &str) -> bool {
	matches!(ext, "y4m" | "mp4" | "mov" | "mkv" | "webm") || is_ts(ext) || is_hls(ext)
}

fn keeps_subtitles(ext: &str, stream: &Stream) -> bool {
	match ext {
		"mkv" | "mka" | "mks" => matroska_holds(stream, false),
		"webm" => stream.parameters.codec.id == "webvtt",
		// HLS carries text subtitles as WebVTT renditions.
		"m3u8" | "hls" | "vtt" | "webvtt" => {
			crate::container::webvtt::holds(&stream.parameters.codec.id)
		}
		_ => false,
	}
}

/// Runs a transcode from `input` to `output`.
pub fn transcode(input: &str, output: &str, options: &Options) -> Result<Summary> {
	// `-threads` applies to this transcode's decoders, not process-wide.
	threading::with_default_threads(options.threads.unwrap_or(0), || {
		let threads = threading::default_threads();
		transcode_with(input, output, options, threads)
	})
}

/// [`transcode`] with `threads` > 1 running demux, decode and encode on
/// separate threads (the codecs use [`threading::default_threads`]).
fn transcode_with(input: &str, output: &str, options: &Options, threads: usize) -> Result<Summary> {
	let ext = container_of(output, options);
	let resolver = Resolver::new();
	let mut summary = Summary::default();

	let mut demuxer = Input::open(input)?;
	let mut muxer = match &options.format {
		Some(format) => Output::create_as(output, format)?,
		None => Output::create(output)?,
	};
	let mut metadata = if options.drop_metadata || ext == "y4m" {
		Metadata::default()
	} else {
		demuxer.metadata().clone()
	};
	apply_metadata(&mut metadata, &options.metadata);
	muxer.set_metadata(metadata)?;
	let mp4_family = matches!(ext.as_str(), "mp4" | "m4a" | "m4v" | "m4b" | "mov");
	for (key, _) in &options.container_options {
		let mp4_key = matches!(key.as_str(), "movflags" | "frag_duration" | "min_frag_duration");
		let fits = if mp4_key {
			mp4_family
		} else if key.starts_with("hls_") || matches!(key.as_str(), "master_pl_name" | "start_number") {
			is_hls(&ext)
		} else {
			is_ts(&ext) || is_hls(&ext)
		};
		if !fits {
			return Err(Message::Container(if mp4_key {
				"-movflags / -frag_duration apply only to MP4, M4A and MOV outputs"
			} else if key.starts_with("hls_") {
				"-hls_* options apply only to HLS (.m3u8) outputs"
			} else {
				"MPEG-TS options apply only to .ts and HLS outputs"
			}));
		}
	}
	for (key, value) in &options.container_options {
		muxer.set_option(key, value)?;
	}

	let streams: Vec<Stream> = demuxer.streams().iter().cloned().collect();
	let mut routes: HashMap<StreamId, Route> = HashMap::new();
	// Decoders apart from the routes, so decoding can run on its own thread.
	let mut decoders: HashMap<StreamId, (Box<dyn Decoder>, State)> = HashMap::new();
	let mut pending: Vec<Packet> = Vec::new();
	let mut next_out = 0usize;

	for stream in &streams {
		let out_id = StreamId(next_out);
		let codec_in = stream.parameters.codec.id.clone();
		match stream.kind {
			StreamKind::Audio if !options.no_audio => {
				let Some(mut default) = default_audio(&ext, stream, options) else { continue };
				if default == "copy" && options.converts_audio() {
					// Resampling or remixing means re-encoding (as in FFmpeg).
					default = match ext.as_str() {
						"webm" | "opus" | "mp3" => {
							return Err(Message::Codec(
								"-ar/-ac/-sample_fmt need re-encoding, and RMP has no encoder for this container's audio",
							));
						}
						"mp4" | "m4a" | "mov" => "aac",
						e if is_ts(e) || is_hls(e) => "aac",
						_ => "flac",
					};
				}
				let codec = options.audio_codec.clone().unwrap_or_else(|| default.to_string());
				if codec == "copy" {
					let mut s = stream.clone();
					s.id = out_id;
					muxer.add(&s)?;
					routes.insert(stream.id, Route::Copy { out: out_id });
					summary.streams.push(format!("stream {}: audio {codec_in} (copy)", stream.id.0));
				} else {
					if !resolver.has_decoder(&codec_in) {
						return Err(Message::Codec(
							"no decoder for the input audio codec (try -c:a copy or -an)",
						));
					}
					let (mut out, target) = audio_target(stream, &codec, options)?;
					let precision = target_precision(&codec, &out, target.format);
					let dither = options.dither.unwrap_or(Dither::TRIANGULAR);
					if !target.format.is_float() {
						dither.check(target.sample_rate)?;
					}
					out.id = out_id;
					muxer.add(&out)?;
					let decoder = resolver.decoder_for(stream).ok_or("no decoder")?;
					let dec_state = decoder.create_state(&stream.parameters);
					decoders.insert(stream.id, (decoder, dec_state));
					let encoder: Box<dyn Encoder> = if codec == "flac" {
						Box::new(FlacEncoder::new(out_id).with_level(options.level.unwrap_or(5)))
					} else if codec == "aac" {
						Box::new(AacEncoder::new(out_id).with_bitrate(options.audio_bitrate))
					} else {
						resolver.encoder_for(&out).ok_or("no encoder")?
					};
					let enc_state = encoder.create_state(&out.parameters);
					summary.streams.push(format!(
						"stream {}: audio {codec_in} -> {codec} ({} Hz, {} ch)",
						stream.id.0, target.sample_rate, target.channels
					));
					routes.insert(
						stream.id,
						Route::Audio(Box::new(AudioRoute {
							out: out_id,
							encoder,
							enc_state,
							target,
							precision,
							dither,
							converter: None,
							gapless: gapless_of(stream),
						})),
					);
				}
				next_out += 1;
			}
			StreamKind::Video if !options.no_video && keeps_video(&ext) => {
				// Scaling or a pixel format change means re-encoding: raw for
				// Y4M, H.264 for the containers that hold it.
				// The H.264 encoder is 4:2:0; other pixel formats stay raw.
				let yuv420 = options.pixel.as_ref().is_none_or(|p| p.name() == "yuv420p");
				let default = match ext.as_str() {
					"y4m" => "rawvideo",
					_ if options.video_bitrate.is_some() || options.qp.is_some() => "h264",
					// MP4 can't hold the codec (VP9 from WebM, say): decode and
					// re-encode when RMP has a decoder.
					"mp4" | "mov" if !muxer_supports(&codec_in) && resolver.has_decoder(&codec_in) => "h264",
					e if (is_ts(e) || is_hls(e))
						&& !output_holds(e, options, &codec_in)
						&& resolver.has_decoder(&codec_in) =>
					{
						"h264"
					}
					_ if options.converts_video() => {
						if yuv420 {
							"h264"
						} else {
							"rawvideo"
						}
					}
					_ => "copy",
				};
				let codec = options.video_codec.clone().unwrap_or_else(|| default.to_string());
				if codec == "copy" {
					let mut s = stream.clone();
					s.id = out_id;
					muxer.add(&s)?;
					routes.insert(stream.id, Route::Copy { out: out_id });
					summary.streams.push(format!("stream {}: video {codec_in} (copy)", stream.id.0));
				} else {
					if codec != "rawvideo" && codec != "h264" {
						return Err(Message::Codec("RMP encodes h264 and rawvideo (or use -c:v copy)"));
					}
					if !resolver.has_decoder(&codec_in) {
						return Err(Message::Codec(
							"no decoder for the input video codec (try -c:v copy or -vn)",
						));
					}
					// Find the frame rate from this stream's first packet.
					let mut first = None;
					while first.is_none() {
						let Some(p) = demuxer.read()? else { break };
						if p.stream_id == stream.id {
							first = p.duration.map(|d| d.ticks());
						}
						pending.push(p);
					}
					let p = &stream.parameters;
					let (w, h) = options.size.unwrap_or((p.width.unwrap_or(0), p.height.unwrap_or(0)));
					let pixel = if codec == "h264" {
						// The encoder takes 8-bit 4:2:0.
						let yuv420p = Pixel::from_name("yuv420p").unwrap_or_default();
						if options.pixel.as_ref().is_some_and(|p| *p != yuv420p) {
							return Err(Message::Codec("the h264 encoder supports only -pix_fmt yuv420p"));
						}
						yuv420p
					} else {
						options
							.pixel
							.clone()
							.or_else(|| p.pixel_format.as_deref().and_then(Pixel::from_name))
							.unwrap_or_default()
					};
					let mut out = Stream::video(out_id, w, h, &pixel.name(), CodecId::new(&codec));
					out.time_base = frame_time_base(stream, first);
					// A re-encode keeps what describes the track, not the coding.
					for key in ["language", "default"] {
						if let Some(v) = stream.metadata.raw.get(key) {
							out.metadata.raw.insert(key.into(), v.clone());
						}
					}
					out.metadata.title = stream.metadata.title.clone();
					let decoder = resolver.decoder_for(stream).ok_or("no decoder")?;
					let dec_state = decoder.create_state(&stream.parameters);
					decoders.insert(stream.id, (decoder, dec_state));
					let encoder: Box<dyn Encoder> = if codec == "h264" {
						let h264 = H264Encoder::new(out_id)
							.with_rate(options.qp, options.video_bitrate)
							.with_gop(options.gop)
							.with_time_base(out.time_base);
						out.parameters.extradata = h264.extradata(&out.parameters)?;
						out.parameters.bitrate = options.video_bitrate;
						Box::new(h264)
					} else {
						resolver.encoder_for(&out).ok_or("no encoder")?
					};
					muxer.add(&out)?;
					let enc_state = encoder.create_state(&out.parameters);
					summary.streams.push(format!(
						"stream {}: video {codec_in} -> {codec} {w}x{h} {}",
						stream.id.0,
						pixel.name()
					));
					routes.insert(
						stream.id,
						Route::Video(Box::new(VideoRoute {
							out: out_id,
							encoder,
							enc_state,
							target: (options.size, Some(pixel)),
							filter: options.filter,
							converter: None,
						})),
					);
				}
				next_out += 1;
			}
			StreamKind::Subtitle if !options.no_subtitles && keeps_subtitles(&ext, stream) => {
				if options.subtitle_codec.as_deref().is_some_and(|c| c != "copy") {
					return Err(Message::Codec("subtitles can only be copied (-c:s copy)"));
				}
				let mut s = stream.clone();
				s.id = out_id;
				muxer.add(&s)?;
				routes.insert(stream.id, Route::Copy { out: out_id });
				summary.streams.push(format!("stream {}: subtitle {codec_in} (copy)", stream.id.0));
				next_out += 1;
			}
			_ => {}
		}
	}
	if routes.is_empty() {
		return Err("no stream to write (check -an/-vn/-sn and the output format)".into());
	}

	let decode = DecodeStage::new(&routes, decoders);
	let encode = EncodeStage { routes, muxer, frames_out: 0, packets_out: 0 };
	let (frames, packets) = if threads > 1 {
		run_pipelined(demuxer, pending, decode, encode)?
	} else {
		run_serial(demuxer, pending, decode, encode)?
	};
	summary.frames = frames;
	summary.packets = packets;
	Ok(summary)
}

/// What the decode stage hands to the encode stage, in input order.
enum Item {
	/// A packet of a copied stream.
	Copy(Packet),
	/// Frames decoded from one packet.
	Frames(StreamId, Vec<Frame>),
	/// End of input for one decoded stream: its last frames (flush order is
	/// output stream order, as before).
	Flushed(StreamId, Vec<Frame>),
	/// Every stream flushed: finish the output.
	End,
	/// Demuxing or decoding failed here; nothing after it is processed.
	Error(Message),
}

/// Demux -> decode. Owns the decoders.
struct DecodeStage {
	decoders: HashMap<StreamId, (Box<dyn Decoder>, State)>,
	copied: std::collections::HashSet<StreamId>,
}

impl DecodeStage {
	fn new(
		routes: &HashMap<StreamId, Route>,
		decoders: HashMap<StreamId, (Box<dyn Decoder>, State)>,
	) -> Self {
		let copied =
			routes.iter().filter(|(_, r)| matches!(r, Route::Copy { .. })).map(|(id, _)| *id).collect();
		Self { decoders, copied }
	}

	fn packet(&mut self, packet: Packet) -> Option<Item> {
		if self.copied.contains(&packet.stream_id) {
			return Some(Item::Copy(packet));
		}
		let id = packet.stream_id;
		let (decoder, state) = self.decoders.get_mut(&id)?;
		Some(match decoder.decode(state, packet) {
			Ok(out) => Item::Frames(id, out.value),
			Err(e) => Item::Error(e),
		})
	}

	/// Flushes every decoder, in output stream order (the input ids sort
	/// the same way) so the result doesn't depend on hash order.
	fn finish(&mut self, mut emit: impl FnMut(Item) -> bool) {
		let mut ids: Vec<StreamId> = self.decoders.keys().copied().collect();
		ids.sort_by_key(|id| id.0);
		for id in ids {
			let Some((decoder, state)) = self.decoders.get_mut(&id) else { continue };
			let item = match decoder.flush(state) {
				Ok(out) => Item::Flushed(id, out.value),
				Err(e) => Item::Error(e),
			};
			let stop = matches!(item, Item::Error(_));
			if !emit(item) || stop {
				return;
			}
		}
		emit(Item::End);
	}
}

/// Convert -> encode -> mux. Owns the encoders and the muxer.
struct EncodeStage {
	routes: HashMap<StreamId, Route>,
	muxer: Output,
	frames_out: u64,
	packets_out: u64,
}

impl EncodeStage {
	/// Processes one item; `Ok(true)` once the output is finished.
	fn item(&mut self, item: Item) -> Result<bool> {
		match item {
			Item::Copy(packet) => {
				let Some(Route::Copy { out }) = self.routes.get(&packet.stream_id) else {
					return Ok(false);
				};
				let mut p = packet;
				p.stream_id = *out;
				self.packets_out += 1;
				self.muxer.write(p)?;
			}
			Item::Frames(id, frames) => self.frames(id, frames)?,
			Item::Flushed(id, frames) => {
				self.frames(id, frames)?;
				if let Some(Route::Audio(r)) = self.routes.get_mut(&id) {
					let (muxer, count) = (&mut self.muxer, &mut self.frames_out);
					for frame in r.gapless.finish() {
						self.packets_out += encode_audio(r, frame, muxer, count)?;
					}
					if let Some(frame) =
						r.converter.as_mut().map(AudioConverter::flush).transpose()?.flatten()
					{
						for mut p in r.encoder.encode(&mut r.enc_state, Frame::Audio(frame))?.value {
							p.stream_id = r.out;
							self.packets_out += 1;
							muxer.write(p)?;
						}
					}
					for mut p in r.encoder.flush(&mut r.enc_state)?.value {
						p.stream_id = r.out;
						self.packets_out += 1;
						muxer.write(p)?;
					}
				}
			}
			Item::End => {
				self.muxer.finish()?;
				return Ok(true);
			}
			Item::Error(e) => return Err(e),
		}
		Ok(false)
	}

	fn frames(&mut self, id: StreamId, frames: Vec<Frame>) -> Result<()> {
		let (muxer, count) = (&mut self.muxer, &mut self.frames_out);
		match self.routes.get_mut(&id) {
			Some(Route::Audio(r)) => self.packets_out += audio_frames(r, frames, muxer, count)?,
			Some(Route::Video(r)) => self.packets_out += video_frames(r, frames, muxer, count)?,
			_ => {}
		}
		Ok(())
	}
}

/// Every stage on the calling thread.
fn run_serial(
	mut demuxer: Input,
	pending: Vec<Packet>,
	mut decode: DecodeStage,
	mut encode: EncodeStage,
) -> Result<(u64, u64)> {
	for packet in pending {
		if let Some(item) = decode.packet(packet) {
			encode.item(item)?;
		}
	}
	while let Some(packet) = demuxer.read()? {
		if let Some(item) = decode.packet(packet) {
			encode.item(item)?;
		}
	}
	let mut result = Ok(false);
	decode.finish(|item| {
		result = encode.item(item);
		result.is_ok()
	});
	match result? {
		true => Ok((encode.frames_out, encode.packets_out)),
		false => Err(Message::Other("transcode: the pipeline stopped before the end")),
	}
}

/// Packets in flight between demuxing and decoding.
const PACKET_QUEUE: usize = 64;
/// Decoded items in flight between decoding and encoding (a few frames:
/// they can be large).
const FRAME_QUEUE: usize = 8;

/// Demuxing on the calling thread, decoding and encoding (with muxing) on
/// one thread each, joined by bounded channels (FFmpeg 7's threaded
/// `ffmpeg` pipeline). Everything flows in input order, so the output is
/// byte-identical to [`run_serial`], and so is the first error reported:
/// a stage that fails passes the error down the line in order, and a
/// stage whose consumer has gone stops at its next send.
fn run_pipelined(
	mut demuxer: Input,
	pending: Vec<Packet>,
	mut decode: DecodeStage,
	mut encode: EncodeStage,
) -> Result<(u64, u64)> {
	use std::sync::mpsc::sync_channel;
	let (packet_tx, packet_rx) = sync_channel::<std::result::Result<Packet, Message>>(PACKET_QUEUE);
	let (item_tx, item_rx) = sync_channel::<Item>(FRAME_QUEUE);
	std::thread::scope(|scope| {
		let decoder =
			std::thread::Builder::new().name("rmp-decode".into()).spawn_scoped(scope, move || {
				for msg in packet_rx {
					let item = match msg {
						Ok(packet) => match decode.packet(packet) {
							Some(item) => item,
							None => continue,
						},
						Err(e) => Item::Error(e),
					};
					let stop = matches!(item, Item::Error(_));
					if item_tx.send(item).is_err() || stop {
						return;
					}
				}
				decode.finish(|item| item_tx.send(item).is_ok());
			});
		let encoder =
			std::thread::Builder::new().name("rmp-encode".into()).spawn_scoped(scope, move || {
				for item in item_rx {
					if encode.item(item)? {
						return Ok((encode.frames_out, encode.packets_out));
					}
				}
				Err(Message::Other("transcode: the pipeline stopped before the end"))
			});
		let (decoder, encoder) = match (decoder, encoder) {
			(Ok(d), Ok(e)) => (d, e),
			_ => return Err(Message::Other("transcode: could not start the pipeline threads")),
		};
		// Demux here. A failed send means a later stage has stopped (with
		// an error that it reports).
		let send = |m| packet_tx.send(m).is_ok();
		let mut open = pending.into_iter().all(|p| send(Ok(p)));
		while open {
			match demuxer.read() {
				Ok(Some(p)) => open = send(Ok(p)),
				Ok(None) => break,
				Err(e) => {
					send(Err(e));
					break;
				}
			}
		}
		drop(packet_tx);
		let _ = decoder.join();
		encoder.join().unwrap_or(Err(Message::Other("transcode: the encode thread panicked")))
	})
}

fn audio_frames(
	r: &mut AudioRoute,
	frames: Vec<Frame>,
	muxer: &mut Output,
	count: &mut u64,
) -> Result<u64> {
	let mut written = 0;
	for frame in frames {
		let Frame::Audio(a) = frame else { continue };
		if a.nb_samples == 0 {
			continue;
		}
		for a in r.gapless.push(a) {
			written += encode_audio(r, a, muxer, count)?;
		}
	}
	Ok(written)
}

/// Converts one decoded frame to the target format and encodes it.
fn encode_audio(
	r: &mut AudioRoute,
	a: crate::core::AudioFrame,
	muxer: &mut Output,
	count: &mut u64,
) -> Result<u64> {
	let converter = match &mut r.converter {
		Some(c) => c,
		None => r
			.converter
			.insert(AudioConverter::new(AudioSpec::of(&a), r.target)?.dithered(r.dither, r.precision)?),
	};
	let Some(converted) = converter.convert(&a)? else { return Ok(0) };
	*count += 1;
	let mut written = 0;
	for mut p in r.encoder.encode(&mut r.enc_state, Frame::Audio(converted))?.value {
		p.stream_id = r.out;
		written += 1;
		muxer.write(p)?;
	}
	Ok(written)
}

fn video_frames(
	r: &mut VideoRoute,
	frames: Vec<Frame>,
	muxer: &mut Output,
	count: &mut u64,
) -> Result<u64> {
	let mut written = 0;
	for frame in frames {
		let Frame::Video(v) = frame else { continue };
		let converter = match &mut r.converter {
			Some(c) => c,
			None => {
				let input = VideoSpec::of(&v);
				let (w, h) = r.target.0.unwrap_or((v.width, v.height));
				let pixel = r.target.1.clone().unwrap_or_else(|| v.pixel.clone());
				let options = VideoOptions { filter: r.filter, ..Default::default() };
				r.converter.insert(VideoConverter::new(input, VideoSpec::new(w, h, pixel), options)?)
			}
		};
		let converted = converter.convert(&v)?;
		*count += 1;
		for mut p in r.encoder.encode(&mut r.enc_state, Frame::Video(converted))?.value {
			p.stream_id = r.out;
			written += 1;
			muxer.write(p)?;
		}
	}
	Ok(written)
}

#[cfg(test)]
mod tests {
	use super::*;

	fn fixture(path: &str) -> String {
		format!("{}/tests/fixtures/{path}", env!("CARGO_MANIFEST_DIR"))
	}

	/// The pipelined transcode writes exactly the bytes of the serial one
	/// (with the codecs' own thread count held fixed).
	#[test]
	fn pipelined_transcode_is_byte_identical() {
		let dir = tempfile::tempdir().unwrap();
		let cases: [(&str, &str, &[&str]); 4] = [
			("mp4/h264_bframes_aac.mp4", "mkv", &["-c:v", "h264", "-c:a", "flac"]),
			("mp4/h264_bframes_aac.mp4", "mp4", &["-c:v", "h264", "-c:a", "aac"]),
			("vp9/tiles_512x128.webm", "y4m", &[]),
			("mp4/h264_high_tools.mp4", "mkv", &["-c", "copy"]),
		];
		for (i, (input, ext, args)) in cases.iter().enumerate() {
			let args: Vec<String> = args.iter().map(|s| s.to_string()).collect();
			let options = Options::parse(&args).unwrap();
			for codec_threads in [1, 3] {
				let out = |pipeline: usize| {
					let path = dir.path().join(format!("{i}_{codec_threads}_{pipeline}.{ext}"));
					let path = path.to_str().unwrap().to_string();
					threading::with_default_threads(codec_threads, || {
						transcode_with(&fixture(input), &path, &options, pipeline).unwrap()
					});
					std::fs::read(&path).unwrap()
				};
				let serial = out(1);
				assert!(!serial.is_empty());
				assert!(out(2) == serial, "{input} -> {ext}, codec threads {codec_threads}");
			}
		}
	}

	#[test]
	fn pipelined_transcode_reports_decode_errors() {
		// A truncated input fails the same way with and without the pipeline.
		let dir = tempfile::tempdir().unwrap();
		let mut data = std::fs::read(fixture("mp4/h264_bframes_aac.mp4")).unwrap();
		data.truncate(data.len() * 2 / 3);
		let input = dir.path().join("cut.mp4");
		std::fs::write(&input, &data).unwrap();
		let input = input.to_str().unwrap();
		let options = Options::parse(&["-c:a".into(), "flac".into()]).unwrap();
		let run = |pipeline: usize| {
			let out = dir.path().join(format!("cut_{pipeline}.mkv"));
			transcode_with(input, out.to_str().unwrap(), &options, pipeline)
				.map(|s| (s.frames, s.packets))
		};
		let (a, b) = (run(1), run(2));
		assert_eq!(a.is_ok(), b.is_ok());
		if let (Ok(a), Ok(b)) = (a, b) {
			assert_eq!(a, b);
		}
	}
}
