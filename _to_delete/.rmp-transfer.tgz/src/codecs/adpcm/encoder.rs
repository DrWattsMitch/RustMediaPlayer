pub struct AdpcmEncoder {}
