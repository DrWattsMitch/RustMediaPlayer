//! Decodes the first audio stream to raw interleaved S16LE PCM and the first
//! video stream to raw planar YUV (like `ffmpeg -f s16le` / `-f rawvideo`).
//!
//! cargo run --release --example decode -- input.mp4 [audio.pcm] [video.yuv]
//!
//! Pass `-` to skip an output. Prints a summary of what was decoded.
use std::fs::File;
use std::io::{BufWriter, Write};

use rmp::Result;
use rmp::core::traits::*;
use rmp::core::{Frame, Resolver, StreamKind};
use rmp::io::Input;

fn open(path: Option<&String>) -> Result<Option<BufWriter<File>>> {
	match path.map(String::as_str) {
		None | Some("-") => Ok(None),
		Some(p) => Ok(Some(BufWriter::new(File::create(p)?))),
	}
}

pub fn main() -> Result<()> {
	let args: Vec<String> = std::env::args().collect();
	let input = args.get(1).ok_or("usage: decode <input> [audio.pcm|-] [video.yuv|-]")?;
	let mut audio_out = open(args.get(2))?;
	let mut video_out = open(args.get(3))?;

	let mut demuxer = Input::open(input)?;
	let resolver = Resolver::new();
	let pick = |kind| demuxer.streams().iter().find(|s| s.kind == kind).cloned();
	let audio = pick(StreamKind::Audio);
	let video = pick(StreamKind::Video);

	let mut audio_dec = audio.as_ref().and_then(|s| {
		resolver.decoder_for(s).map(|d| {
			let st = d.create_state(&s.parameters);
			(s.id, d, st)
		})
	});
	let mut video_dec = video.as_ref().and_then(|s| {
		resolver.decoder_for(s).map(|d| {
			let st = d.create_state(&s.parameters);
			(s.id, d, st)
		})
	});

	let (mut samples, mut pictures) = (0usize, 0usize);
	let mut sink = |frames: Vec<Frame>, samples: &mut usize, pictures: &mut usize| -> Result<()> {
		for frame in frames {
			match frame {
				Frame::Audio(a) => {
					*samples += a.nb_samples;
					if let Some(w) = audio_out.as_mut() {
						w.write_all(&a.data)?;
					}
				}
				Frame::Video(v) => {
					*pictures += 1;
					if let Some(w) = video_out.as_mut() {
						w.write_all(&v.data)?;
					}
				}
			}
		}
		Ok(())
	};

	while let Some(packet) = demuxer.read()? {
		let target = [audio_dec.as_mut(), video_dec.as_mut()]
			.into_iter()
			.flatten()
			.find(|(id, _, _)| *id == packet.stream_id);
		if let Some((_, dec, st)) = target {
			let frames = dec.decode(st, packet)?.value;
			sink(frames, &mut samples, &mut pictures)?;
		}
	}
	if let Some((_, dec, st)) = audio_dec.as_mut() {
		let frames = dec.flush(st)?.value;
		sink(frames, &mut samples, &mut pictures)?;
	}
	if let Some((_, dec, st)) = video_dec.as_mut() {
		let frames = dec.flush(st)?.value;
		sink(frames, &mut samples, &mut pictures)?;
	}
	if let Some(mut w) = audio_out {
		w.flush()?;
	}
	if let Some(mut w) = video_out {
		w.flush()?;
	}
	println!("audio samples per channel: {samples}");
	println!("video frames: {pictures}");
	Ok(())
}
