use super::packet::detect_layout;
use crate::core::{Demuxer, Hint, Muxer, Probe};
use crate::io::Io;
use crate::message::{Message, Result};

pub struct TsProbe;

impl Probe for TsProbe {
	/// A run of sync bytes at a 188, 192 or 204-byte stride, like FFmpeg's
	/// `mpegts_probe`.
	fn demuxer_matches(data: &[u8]) -> bool {
		detect_layout(data).is_some()
	}

	fn muxer_matches(_hint: &Hint) -> bool {
		false
	}

	fn create_demuxer(io: Box<dyn Io>) -> Result<Box<dyn Demuxer>> {
		Ok(Box::new(super::TsDemuxer::new(io)?))
	}

	fn create_muxer(_io: Box<dyn Io>) -> Result<Box<dyn Muxer>> {
		Err(Message::Container("mpeg-ts output is not supported"))
	}
}
